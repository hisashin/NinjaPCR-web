
	var NEW_EXPERIMENT = {
		"name" : "New Experiment",
		"steps" : [ {
			"type" : "cycle",
			"count" : "",
			"steps" : [ {
				"type" : "step",
				"name" : "Denaturing",
				"time" : "",
				"temp" : "",
				"rampDuration" : 0
			}, {
				"type" : "step",
				"name" : "Annealing",
				"time" : "",
				"temp" : "",
				"rampDuration" : 0
			}, {
				"type" : "step",
				"name" : "Extending",
				"time" : "",
				"temp" : "",
				"rampDuration" : 0
			} ]
		}, {
			"type" : "step",
			"name" : "Final Hold",
			"temp" : "20",
			"time" : 0,
			"rampDuration" : 0
		} ],
		"lidtemp" : 110
	};